const ProductScreen = {
    render:()=>{
        return `<div>ProductScreen</div>`;
    },
};
export default ProductScreen;